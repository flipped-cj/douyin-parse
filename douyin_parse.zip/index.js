const serverless = require('serverless-http')
const app = require('./app')

app.listen(3000)

exports.main = serverless(app)
